# OpenAPI\Client\GameApi

All URIs are relative to https://codedef1.duckdns.org, except if the operation defines another base path.

| Method | HTTP request | Description |
| ------------- | ------------- | ------------- |
| [**claimEquivalent()**](GameApi.md#claimEquivalent) | **POST** /api/game/mutant/equivalences/claim | Claim a mutant as equivalent |
| [**endGame()**](GameApi.md#endGame) | **POST** /admin/api/game/end | End a game |
| [**getAllEvents()**](GameApi.md#getAllEvents) | **GET** /admin/api/events | Get events and scores from all created games |
| [**getClass()**](GameApi.md#getClass) | **GET** /api/class | Get a class |
| [**getGameRole()**](GameApi.md#getGameRole) | **GET** /api/game/role | Get game role |
| [**getMutant()**](GameApi.md#getMutant) | **GET** /api/game/mutant | Get a mutant |
| [**getPendingEquivalences()**](GameApi.md#getPendingEquivalences) | **GET** /api/game/mutant/equivalences | Get unresolved equivalence claims |
| [**getServerLoad()**](GameApi.md#getServerLoad) | **GET** /admin/api/load | Get server load |
| [**getSettings()**](GameApi.md#getSettings) | **GET** /api/game/settings | Get game settings |
| [**getStatus()**](GameApi.md#getStatus) | **GET** /api/game | Get game status |
| [**getTest()**](GameApi.md#getTest) | **GET** /api/game/test | Get a test |
| [**getTestTemplate()**](GameApi.md#getTestTemplate) | **GET** /api/game/test/template | Get the test template |
| [**graceOneGame()**](GameApi.md#graceOneGame) | **POST** /admin/api/game/disable-uploads | Disable uploads in a game |
| [**graceTwoGame()**](GameApi.md#graceTwoGame) | **POST** /admin/api/game/disable-claims | Disable mutant claims in a game |
| [**newGame()**](GameApi.md#newGame) | **POST** /admin/api/game | Create a new game |
| [**resolveEquivalence()**](GameApi.md#resolveEquivalence) | **POST** /api/game/mutant/equivalences/resolve | Resolve pending equivalence |
| [**startGame()**](GameApi.md#startGame) | **POST** /admin/api/game/start | Start a game |
| [**uploadClass()**](GameApi.md#uploadClass) | **POST** /api/admin/class/upload | Upload a class |
| [**uploadMutant()**](GameApi.md#uploadMutant) | **POST** /api/game/mutant | Upload a mutant |
| [**uploadTest()**](GameApi.md#uploadTest) | **POST** /api/game/test | Upload a test |


## `claimEquivalent()`

```php
claimEquivalent($claim_equivalent_request)
```

Claim a mutant as equivalent

Claim all mutants on the specified line as equivalent, meaning that they doesn't affect the behavior of the code.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\GameApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$claim_equivalent_request = new \OpenAPI\Client\Model\ClaimEquivalentRequest(); // \OpenAPI\Client\Model\ClaimEquivalentRequest

try {
    $apiInstance->claimEquivalent($claim_equivalent_request);
} catch (Exception $e) {
    echo 'Exception when calling GameApi->claimEquivalent: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **claim_equivalent_request** | [**\OpenAPI\Client\Model\ClaimEquivalentRequest**](../Model/ClaimEquivalentRequest.md)|  | |

### Return type

void (empty response body)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `endGame()`

```php
endGame($end_game_request)
```

End a game

End a game

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\GameApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$end_game_request = new \OpenAPI\Client\Model\EndGameRequest(); // \OpenAPI\Client\Model\EndGameRequest

try {
    $apiInstance->endGame($end_game_request);
} catch (Exception $e) {
    echo 'Exception when calling GameApi->endGame: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **end_game_request** | [**\OpenAPI\Client\Model\EndGameRequest**](../Model/EndGameRequest.md)|  | |

### Return type

void (empty response body)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `getAllEvents()`

```php
getAllEvents($from_timestamp): \OpenAPI\Client\Model\EventList
```

Get events and scores from all created games

Get events and scores from all games created by the logged user, starting from the specified time Only scores for games that also have events are returned

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\GameApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$from_timestamp = 'from_timestamp_example'; // string | The minimum timestamp of the events

try {
    $result = $apiInstance->getAllEvents($from_timestamp);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling GameApi->getAllEvents: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **from_timestamp** | **string**| The minimum timestamp of the events | |

### Return type

[**\OpenAPI\Client\Model\EventList**](../Model/EventList.md)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `getClass()`

```php
getClass($class_id): \OpenAPI\Client\Model\ModelClass
```

Get a class

Get a class by its ID

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\GameApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$class_id = 56; // int | The class ID

try {
    $result = $apiInstance->getClass($class_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling GameApi->getClass: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **class_id** | **int**| The class ID | |

### Return type

[**\OpenAPI\Client\Model\ModelClass**](../Model/ModelClass.md)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `getGameRole()`

```php
getGameRole($game_id): \OpenAPI\Client\Model\GetGameRole200Response
```

Get game role

Get own role in the game with the specified ID

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\GameApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$game_id = 56; // int | The game ID

try {
    $result = $apiInstance->getGameRole($game_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling GameApi->getGameRole: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **game_id** | **int**| The game ID | |

### Return type

[**\OpenAPI\Client\Model\GetGameRole200Response**](../Model/GetGameRole200Response.md)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `getMutant()`

```php
getMutant($mutant_id): \OpenAPI\Client\Model\Mutant
```

Get a mutant

Get a mutant by its ID

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\GameApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$mutant_id = 56; // int | The mutant ID

try {
    $result = $apiInstance->getMutant($mutant_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling GameApi->getMutant: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **mutant_id** | **int**| The mutant ID | |

### Return type

[**\OpenAPI\Client\Model\Mutant**](../Model/Mutant.md)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `getPendingEquivalences()`

```php
getPendingEquivalences($game_id): \OpenAPI\Client\Model\GetPendingEquivalences200Response
```

Get unresolved equivalence claims

Get unresolved equivalence claims for the game with the specified ID

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\GameApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$game_id = 56; // int | The game ID

try {
    $result = $apiInstance->getPendingEquivalences($game_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling GameApi->getPendingEquivalences: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **game_id** | **int**| The game ID | |

### Return type

[**\OpenAPI\Client\Model\GetPendingEquivalences200Response**](../Model/GetPendingEquivalences200Response.md)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `getServerLoad()`

```php
getServerLoad(): \OpenAPI\Client\Model\GetServerLoad200Response
```

Get server load

Get server load (count of active battleground and melee games)

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\GameApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);

try {
    $result = $apiInstance->getServerLoad();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling GameApi->getServerLoad: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

This endpoint does not need any parameter.

### Return type

[**\OpenAPI\Client\Model\GetServerLoad200Response**](../Model/GetServerLoad200Response.md)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `getSettings()`

```php
getSettings($game_id): \OpenAPI\Client\Model\GameSettings
```

Get game settings

Get the settings of the game with the specified ID

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\GameApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$game_id = 56; // int | The game ID

try {
    $result = $apiInstance->getSettings($game_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling GameApi->getSettings: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **game_id** | **int**| The game ID | |

### Return type

[**\OpenAPI\Client\Model\GameSettings**](../Model/GameSettings.md)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `getStatus()`

```php
getStatus($game_id): \OpenAPI\Client\Model\GameStatus
```

Get game status

Get the status of the game with the specified ID

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\GameApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$game_id = 56; // int | The game ID

try {
    $result = $apiInstance->getStatus($game_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling GameApi->getStatus: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **game_id** | **int**| The game ID | |

### Return type

[**\OpenAPI\Client\Model\GameStatus**](../Model/GameStatus.md)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `getTest()`

```php
getTest($test_id): \OpenAPI\Client\Model\Test
```

Get a test

Get a test by its ID

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\GameApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$test_id = 56; // int | The test ID

try {
    $result = $apiInstance->getTest($test_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling GameApi->getTest: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **test_id** | **int**| The test ID | |

### Return type

[**\OpenAPI\Client\Model\Test**](../Model/Test.md)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `getTestTemplate()`

```php
getTestTemplate($game_id): \OpenAPI\Client\Model\GetTestTemplate200Response
```

Get the test template

Get the test template for the game with the specified ID

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\GameApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$game_id = 56; // int | The game ID

try {
    $result = $apiInstance->getTestTemplate($game_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling GameApi->getTestTemplate: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **game_id** | **int**| The game ID | |

### Return type

[**\OpenAPI\Client\Model\GetTestTemplate200Response**](../Model/GetTestTemplate200Response.md)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `graceOneGame()`

```php
graceOneGame($grace_one_game_request)
```

Disable uploads in a game

Disable class and mutant uploads in a game (advance it to the grace one phase)

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\GameApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$grace_one_game_request = new \OpenAPI\Client\Model\GraceOneGameRequest(); // \OpenAPI\Client\Model\GraceOneGameRequest

try {
    $apiInstance->graceOneGame($grace_one_game_request);
} catch (Exception $e) {
    echo 'Exception when calling GameApi->graceOneGame: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **grace_one_game_request** | [**\OpenAPI\Client\Model\GraceOneGameRequest**](../Model/GraceOneGameRequest.md)|  | |

### Return type

void (empty response body)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `graceTwoGame()`

```php
graceTwoGame($grace_one_game_request)
```

Disable mutant claims in a game

Disable mutant claims in a game (advance it to the grace two phase)

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\GameApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$grace_one_game_request = new \OpenAPI\Client\Model\GraceOneGameRequest(); // \OpenAPI\Client\Model\GraceOneGameRequest

try {
    $apiInstance->graceTwoGame($grace_one_game_request);
} catch (Exception $e) {
    echo 'Exception when calling GameApi->graceTwoGame: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **grace_one_game_request** | [**\OpenAPI\Client\Model\GraceOneGameRequest**](../Model/GraceOneGameRequest.md)|  | |

### Return type

void (empty response body)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `newGame()`

```php
newGame($new_game_request): \OpenAPI\Client\Model\NewGame200Response
```

Create a new game

Create a new game with the specified class, settings and teams

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\GameApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$new_game_request = new \OpenAPI\Client\Model\NewGameRequest(); // \OpenAPI\Client\Model\NewGameRequest | 

try {
    $result = $apiInstance->newGame($new_game_request);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling GameApi->newGame: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **new_game_request** | [**\OpenAPI\Client\Model\NewGameRequest**](../Model/NewGameRequest.md)|  | |

### Return type

[**\OpenAPI\Client\Model\NewGame200Response**](../Model/NewGame200Response.md)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `resolveEquivalence()`

```php
resolveEquivalence($resolve_equivalence_request): \OpenAPI\Client\Model\ResolveEquivalence200Response
```

Resolve pending equivalence

Resolve the pending equivalence claim for a mutant, either by accepting it as equal or uploading the code for a killing test

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\GameApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$resolve_equivalence_request = new \OpenAPI\Client\Model\ResolveEquivalenceRequest(); // \OpenAPI\Client\Model\ResolveEquivalenceRequest

try {
    $result = $apiInstance->resolveEquivalence($resolve_equivalence_request);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling GameApi->resolveEquivalence: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **resolve_equivalence_request** | [**\OpenAPI\Client\Model\ResolveEquivalenceRequest**](../Model/ResolveEquivalenceRequest.md)|  | |

### Return type

[**\OpenAPI\Client\Model\ResolveEquivalence200Response**](../Model/ResolveEquivalence200Response.md)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `startGame()`

```php
startGame($start_game_request)
```

Start a game

Start a game

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\GameApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$start_game_request = new \OpenAPI\Client\Model\StartGameRequest(); // \OpenAPI\Client\Model\StartGameRequest

try {
    $apiInstance->startGame($start_game_request);
} catch (Exception $e) {
    echo 'Exception when calling GameApi->startGame: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **start_game_request** | [**\OpenAPI\Client\Model\StartGameRequest**](../Model/StartGameRequest.md)|  | |

### Return type

void (empty response body)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `uploadClass()`

```php
uploadClass($upload_class_request): \OpenAPI\Client\Model\UploadClass200Response
```

Upload a class

Upload a class providing name and source

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\GameApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$upload_class_request = new \OpenAPI\Client\Model\UploadClassRequest(); // \OpenAPI\Client\Model\UploadClassRequest

try {
    $result = $apiInstance->uploadClass($upload_class_request);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling GameApi->uploadClass: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **upload_class_request** | [**\OpenAPI\Client\Model\UploadClassRequest**](../Model/UploadClassRequest.md)|  | |

### Return type

[**\OpenAPI\Client\Model\UploadClass200Response**](../Model/UploadClass200Response.md)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `uploadMutant()`

```php
uploadMutant($upload_mutant_request): \OpenAPI\Client\Model\UploadMutant200Response
```

Upload a mutant

Upload a mutant providing its code and target game

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\GameApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$upload_mutant_request = new \OpenAPI\Client\Model\UploadMutantRequest(); // \OpenAPI\Client\Model\UploadMutantRequest

try {
    $result = $apiInstance->uploadMutant($upload_mutant_request);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling GameApi->uploadMutant: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **upload_mutant_request** | [**\OpenAPI\Client\Model\UploadMutantRequest**](../Model/UploadMutantRequest.md)|  | |

### Return type

[**\OpenAPI\Client\Model\UploadMutant200Response**](../Model/UploadMutant200Response.md)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `uploadTest()`

```php
uploadTest($upload_test_request): \OpenAPI\Client\Model\UploadTest200Response
```

Upload a test

Upload a test providing its code and target game

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\GameApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$upload_test_request = new \OpenAPI\Client\Model\UploadTestRequest(); // \OpenAPI\Client\Model\UploadTestRequest

try {
    $result = $apiInstance->uploadTest($upload_test_request);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling GameApi->uploadTest: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **upload_test_request** | [**\OpenAPI\Client\Model\UploadTestRequest**](../Model/UploadTestRequest.md)|  | |

### Return type

[**\OpenAPI\Client\Model\UploadTest200Response**](../Model/UploadTest200Response.md)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)
