# OpenAPI\Client\AdminApi

All URIs are relative to https://codedef1.duckdns.org, except if the operation defines another base path.

| Method | HTTP request | Description |
| ------------- | ------------- | ------------- |
| [**endGame()**](AdminApi.md#endGame) | **POST** /admin/api/game/end | End a game |
| [**generateNewUser()**](AdminApi.md#generateNewUser) | **GET** /admin/api/auth/newUser | Generate a new user |
| [**getAllEvents()**](AdminApi.md#getAllEvents) | **GET** /admin/api/events | Get events and scores from all created games |
| [**getSelfAdmin()**](AdminApi.md#getSelfAdmin) | **GET** /admin/api/auth/self | Get own information |
| [**getServerLoad()**](AdminApi.md#getServerLoad) | **GET** /admin/api/load | Get server load |
| [**getUserToken()**](AdminApi.md#getUserToken) | **GET** /admin/api/auth/token | Get an authentication token for the Bot API |
| [**graceOneGame()**](AdminApi.md#graceOneGame) | **POST** /admin/api/game/disable-uploads | Disable uploads in a game |
| [**graceTwoGame()**](AdminApi.md#graceTwoGame) | **POST** /admin/api/game/disable-claims | Disable mutant claims in a game |
| [**newGame()**](AdminApi.md#newGame) | **POST** /admin/api/game | Create a new game |
| [**startGame()**](AdminApi.md#startGame) | **POST** /admin/api/game/start | Start a game |
| [**uploadClass()**](AdminApi.md#uploadClass) | **POST** /api/admin/class/upload | Upload a class |


## `endGame()`

```php
endGame($end_game_request)
```

End a game

End a game

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\AdminApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$end_game_request = new \OpenAPI\Client\Model\EndGameRequest(); // \OpenAPI\Client\Model\EndGameRequest

try {
    $apiInstance->endGame($end_game_request);
} catch (Exception $e) {
    echo 'Exception when calling AdminApi->endGame: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **end_game_request** | [**\OpenAPI\Client\Model\EndGameRequest**](../Model/EndGameRequest.md)|  | |

### Return type

void (empty response body)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `generateNewUser()`

```php
generateNewUser($name): \OpenAPI\Client\Model\GenerateNewUser200Response
```

Generate a new user

Generate a new user with a name in the format `{creatorUsername}_{username}_{randomNumbers}`

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\AdminApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$name = 'name_example'; // string | The name part of the generated username

try {
    $result = $apiInstance->generateNewUser($name);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AdminApi->generateNewUser: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **name** | **string**| The name part of the generated username | |

### Return type

[**\OpenAPI\Client\Model\GenerateNewUser200Response**](../Model/GenerateNewUser200Response.md)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `getAllEvents()`

```php
getAllEvents($from_timestamp): \OpenAPI\Client\Model\EventList
```

Get events and scores from all created games

Get events and scores from all games created by the logged user, starting from the specified time Only scores for games that also have events are returned

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\AdminApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$from_timestamp = 'from_timestamp_example'; // string | The minimum timestamp of the events

try {
    $result = $apiInstance->getAllEvents($from_timestamp);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AdminApi->getAllEvents: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **from_timestamp** | **string**| The minimum timestamp of the events | |

### Return type

[**\OpenAPI\Client\Model\EventList**](../Model/EventList.md)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `getSelfAdmin()`

```php
getSelfAdmin(): \OpenAPI\Client\Model\GetSelf200Response
```

Get own information

Get own information (userId, username, API token). This API has the same functionality as getSelf, but it can be called only by admins, so it can be used as a permission check.

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\AdminApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);

try {
    $result = $apiInstance->getSelfAdmin();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AdminApi->getSelfAdmin: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

This endpoint does not need any parameter.

### Return type

[**\OpenAPI\Client\Model\GetSelf200Response**](../Model/GetSelf200Response.md)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `getServerLoad()`

```php
getServerLoad(): \OpenAPI\Client\Model\GetServerLoad200Response
```

Get server load

Get server load (count of active battleground and melee games)

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\AdminApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);

try {
    $result = $apiInstance->getServerLoad();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AdminApi->getServerLoad: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

This endpoint does not need any parameter.

### Return type

[**\OpenAPI\Client\Model\GetServerLoad200Response**](../Model/GetServerLoad200Response.md)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `getUserToken()`

```php
getUserToken($user_id): \OpenAPI\Client\Model\GetUserToken200Response
```

Get an authentication token for the Bot API

Get an authentication token for the Bot API, tied to a specific user

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\AdminApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$user_id = 56; // int | The user for which to get the token. Must have been created by TA

try {
    $result = $apiInstance->getUserToken($user_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AdminApi->getUserToken: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **user_id** | **int**| The user for which to get the token. Must have been created by TA | |

### Return type

[**\OpenAPI\Client\Model\GetUserToken200Response**](../Model/GetUserToken200Response.md)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `graceOneGame()`

```php
graceOneGame($grace_one_game_request)
```

Disable uploads in a game

Disable class and mutant uploads in a game (advance it to the grace one phase)

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\AdminApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$grace_one_game_request = new \OpenAPI\Client\Model\GraceOneGameRequest(); // \OpenAPI\Client\Model\GraceOneGameRequest

try {
    $apiInstance->graceOneGame($grace_one_game_request);
} catch (Exception $e) {
    echo 'Exception when calling AdminApi->graceOneGame: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **grace_one_game_request** | [**\OpenAPI\Client\Model\GraceOneGameRequest**](../Model/GraceOneGameRequest.md)|  | |

### Return type

void (empty response body)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `graceTwoGame()`

```php
graceTwoGame($grace_one_game_request)
```

Disable mutant claims in a game

Disable mutant claims in a game (advance it to the grace two phase)

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\AdminApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$grace_one_game_request = new \OpenAPI\Client\Model\GraceOneGameRequest(); // \OpenAPI\Client\Model\GraceOneGameRequest

try {
    $apiInstance->graceTwoGame($grace_one_game_request);
} catch (Exception $e) {
    echo 'Exception when calling AdminApi->graceTwoGame: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **grace_one_game_request** | [**\OpenAPI\Client\Model\GraceOneGameRequest**](../Model/GraceOneGameRequest.md)|  | |

### Return type

void (empty response body)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `newGame()`

```php
newGame($new_game_request): \OpenAPI\Client\Model\NewGame200Response
```

Create a new game

Create a new game with the specified class, settings and teams

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\AdminApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$new_game_request = new \OpenAPI\Client\Model\NewGameRequest(); // \OpenAPI\Client\Model\NewGameRequest | 

try {
    $result = $apiInstance->newGame($new_game_request);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AdminApi->newGame: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **new_game_request** | [**\OpenAPI\Client\Model\NewGameRequest**](../Model/NewGameRequest.md)|  | |

### Return type

[**\OpenAPI\Client\Model\NewGame200Response**](../Model/NewGame200Response.md)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `startGame()`

```php
startGame($start_game_request)
```

Start a game

Start a game

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\AdminApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$start_game_request = new \OpenAPI\Client\Model\StartGameRequest(); // \OpenAPI\Client\Model\StartGameRequest

try {
    $apiInstance->startGame($start_game_request);
} catch (Exception $e) {
    echo 'Exception when calling AdminApi->startGame: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **start_game_request** | [**\OpenAPI\Client\Model\StartGameRequest**](../Model/StartGameRequest.md)|  | |

### Return type

void (empty response body)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)

## `uploadClass()`

```php
uploadClass($upload_class_request): \OpenAPI\Client\Model\UploadClass200Response
```

Upload a class

Upload a class providing name and source

### Example

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');


// Configure Bearer authorization: BearerToken
$config = OpenAPI\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new OpenAPI\Client\Api\AdminApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$upload_class_request = new \OpenAPI\Client\Model\UploadClassRequest(); // \OpenAPI\Client\Model\UploadClassRequest

try {
    $result = $apiInstance->uploadClass($upload_class_request);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AdminApi->uploadClass: ', $e->getMessage(), PHP_EOL;
}
```

### Parameters

| Name | Type | Description  | Notes |
| ------------- | ------------- | ------------- | ------------- |
| **upload_class_request** | [**\OpenAPI\Client\Model\UploadClassRequest**](../Model/UploadClassRequest.md)|  | |

### Return type

[**\OpenAPI\Client\Model\UploadClass200Response**](../Model/UploadClass200Response.md)

### Authorization

[BearerToken](../../README.md#BearerToken)

### HTTP request headers

- **Content-Type**: `application/json`
- **Accept**: `application/json`

[[Back to top]](#) [[Back to API list]](../../README.md#endpoints)
[[Back to Model list]](../../README.md#models)
[[Back to README]](../../README.md)
