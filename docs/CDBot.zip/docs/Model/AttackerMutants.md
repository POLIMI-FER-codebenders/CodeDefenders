# # AttackerMutants

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**alive** | **int** |  |
**killed** | **int** |  |
**equivalent** | **int** |  |
**total** | **int** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
