# # Event

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**user_id** | **int** |  |
**message** | **string** |  |
**type** | **string** |  |
**timestamp** | **int** |  |
**scoreboard** | [**\OpenAPI\Client\Model\EventScoreboard**](EventScoreboard.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
