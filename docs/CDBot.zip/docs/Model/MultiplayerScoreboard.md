# # MultiplayerScoreboard

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**attackers** | [**\OpenAPI\Client\Model\Attacker[]**](Attacker.md) |  |
**attackers_total** | [**\OpenAPI\Client\Model\Attacker**](Attacker.md) |  |
**defenders** | [**\OpenAPI\Client\Model\Defender[]**](Defender.md) |  |
**defenders_total** | [**\OpenAPI\Client\Model\Defender**](Defender.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
