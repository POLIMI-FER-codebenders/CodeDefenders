# # GetSelf200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**user_id** | **int** | Own user ID | [optional]
**username** | **string** | Own username | [optional]
**token** | **string** | Own API token |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
