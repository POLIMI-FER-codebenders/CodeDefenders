# # UserPoints

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total** | **int** |  |
**from_mutants** | **int** |  |
**from_tests** | **int** |  |
**avg_per_test** | **float** |  |
**avg_per_mutant** | **float** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
