# # KillMapInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mutant_id** | **int** |  |
**test_id** | **int** |  |
**status** | **string** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
