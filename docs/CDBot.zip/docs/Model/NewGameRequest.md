# # NewGameRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**class_id** | **int** | The ID of the class to use for the game |
**teams** | [**\OpenAPI\Client\Model\NewGameRequestTeamsInner[]**](NewGameRequestTeamsInner.md) | The teams participating to the game |
**settings** | [**\OpenAPI\Client\Model\GameSettings**](GameSettings.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
