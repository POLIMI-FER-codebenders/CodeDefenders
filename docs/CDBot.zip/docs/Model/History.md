# # History

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**games** | [**\OpenAPI\Client\Model\GameStatus[]**](GameStatus.md) |  |
**mutant_sources** | **array<string,string>** |  |
**test_sources** | **array<string,string>** |  |
**classes** | [**\OpenAPI\Client\Model\ClassInfo[]**](ClassInfo.md) |  |
**kill_maps** | [**\OpenAPI\Client\Model\KillMapInfo[]**](KillMapInfo.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
