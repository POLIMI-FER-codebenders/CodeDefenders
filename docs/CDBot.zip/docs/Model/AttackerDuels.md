# # AttackerDuels

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**won** | **int** |  |
**lost** | **int** |  |
**ongoing** | **int** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
