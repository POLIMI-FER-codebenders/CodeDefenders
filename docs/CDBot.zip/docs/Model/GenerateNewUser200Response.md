# # GenerateNewUser200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**user_id** | **int** | The ID of the generated user |
**username** | **string** | The username of the generated user |
**token** | **string** | The login token of the generated user |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
