# # TestInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  |
**player_id** | **int** |  |
**covered_lines** | **int[]** |  |
**points** | **int** |  |
**covered_mutant_ids** | **int[]** |  | [optional]
**killed_mutant_ids** | **int[]** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
