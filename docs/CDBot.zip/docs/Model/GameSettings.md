# # GameSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**game_type** | **string** |  |
**game_level** | **string** |  |
**mutant_validator_level** | **string** |  |
**max_assertions_per_test** | **int** |  |
**auto_equivalence_threshold** | **int** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
