# # MutantInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  |
**player_id** | **int** |  |
**state** | **string** |  |
**mutated_lines** | **int[]** |  |
**points** | **int** |  |
**killing_test_id** | **int** |  | [optional]
**can_mark_equivalent** | **bool** |  | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
