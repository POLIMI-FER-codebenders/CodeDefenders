# # ResolveEquivalenceRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mutant_id** | **int** | The mutant ID |
**accept** | **bool** | &#x60;true&#x60; to accept the mutant as equivalent, &#x60;false&#x60; to dispute the claim |
**source** | **string** | The source code of a killing test for the mutant, required if &#x60;accept&#x60; is set to &#x60;false&#x60; | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
