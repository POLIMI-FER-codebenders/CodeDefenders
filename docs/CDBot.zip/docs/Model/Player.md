# # Player

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **string** |  |
**user_id** | **int** |  |
**player_id** | **int** |  |
**points** | **int** |  |
**attack_points** | **int** |  |
**defense_points** | **int** |  |
**duel_points** | **int** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
