# # MeleeScoreboard

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**players** | [**\OpenAPI\Client\Model\Player[]**](Player.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
