# # GetServerLoad200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**battleground** | **int** | Count of active battleground games |
**melee** | **int** | Count of active melee games |
**total** | **int** | Total count of active games |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
