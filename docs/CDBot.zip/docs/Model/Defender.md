# # Defender

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **string** |  |
**user_id** | **int** |  |
**player_id** | **int** |  |
**tests** | [**\OpenAPI\Client\Model\DefenderTests**](DefenderTests.md) |  |
**duels** | [**\OpenAPI\Client\Model\AttackerDuels**](AttackerDuels.md) |  |
**points** | **int** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
