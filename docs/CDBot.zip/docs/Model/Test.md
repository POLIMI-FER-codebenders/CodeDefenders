# # Test

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Test ID |
**player_id** | **int** | Creator&#39;s playerId |
**game_id** | **int** | ID of the game the test is used in |
**source** | **string** | Test code | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
