# # EventList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**events** | **array<string,\OpenAPI\Client\Model\Event[]>** |  |
**has_more** | **bool** | &#x60;true&#x60; if there are more events after the last one returned |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
