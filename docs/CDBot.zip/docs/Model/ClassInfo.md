# # ClassInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Class ID |
**name** | **string** | Class name |
**alias** | **string** | Class alias |
**source** | **string** | Class code |
**testing_framework** | **string** |  |
**assertion_library** | **string** |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
