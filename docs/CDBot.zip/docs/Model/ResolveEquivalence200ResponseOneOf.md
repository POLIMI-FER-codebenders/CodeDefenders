# # ResolveEquivalence200ResponseOneOf

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**killed_claimed** | **bool** | Whether the claimed mutant was killed with the uploaded test |
**killed_others** | **int** | Count of other claimed mutants killed with the uploaded test |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
