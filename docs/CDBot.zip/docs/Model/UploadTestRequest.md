# # UploadTestRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**game_id** | **int** | The target game ID |
**source** | **string** | The test&#39;s code |
**selected_line** | **int** | The line the test will defend Required only if capturing intentions is enabled for the game | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
