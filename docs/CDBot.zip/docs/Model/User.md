# # User

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **string** |  |
**mutants** | [**\OpenAPI\Client\Model\UserMutants**](UserMutants.md) |  |
**tests** | [**\OpenAPI\Client\Model\UserTests**](UserTests.md) |  |
**points** | [**\OpenAPI\Client\Model\UserPoints**](UserPoints.md) |  |
**games** | [**\OpenAPI\Client\Model\UserGames**](UserGames.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
