# # ClaimEquivalentRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**game_id** | **int** | The target game ID |
**lines** | **int[]** | A line modified by the supposedly equivalent mutant |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
