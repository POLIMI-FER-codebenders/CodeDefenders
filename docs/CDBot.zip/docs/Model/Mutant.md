# # Mutant

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Mutant ID |
**player_id** | **int** | Creator&#39;s playerId |
**game_id** | **int** | ID of the game the mutant is used in |
**diff** | **string** | Mutant diff to original class | [optional]

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
