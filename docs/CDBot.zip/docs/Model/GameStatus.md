# # GameStatus

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**game_id** | **int** |  | [optional]
**class_id** | **int** |  |
**state** | **string** |  |
**capture_players_intention** | **bool** |  | [optional]
**mutants** | [**\OpenAPI\Client\Model\MutantInfo[]**](MutantInfo.md) |  |
**tests** | [**\OpenAPI\Client\Model\TestInfo[]**](TestInfo.md) |  |
**scoreboard** | [**\OpenAPI\Client\Model\GameStatusScoreboard**](GameStatusScoreboard.md) |  |

[[Back to Model list]](../../README.md#models) [[Back to API list]](../../README.md#endpoints) [[Back to README]](../../README.md)
