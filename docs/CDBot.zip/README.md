Log into CodeDefenders
Get API token in the profile page
Join a game (battleground or melee, attacker or defender)
`php bot.php {game_id} {api_token}`