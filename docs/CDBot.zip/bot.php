<?php
require_once(__DIR__ . '/vendor/autoload.php');
use GuzzleHttp\HandlerStack;
use GuzzleHttp\Middleware;
use Psr\Http\Message\RequestInterface;
use Psr\Http\Message\ResponseInterface;

define('debugLevel',2); #0 - Nothing; 1 - Print request type, path and query, response code; 2 - Print request and response body
define('host',"http://localhost:8080");

$stack = HandlerStack::create();
$stack->push(Middleware::mapRequest(function (RequestInterface $request)
{
	$method=$request->getMethod();
	$path=$request->getUri()->getPath();
	$query=$request->getUri()->getQuery();
	$body=(string)$request->getBody();
	if(debugLevel)
	{
		echo "\e[33m".$method." \e[93m".$path.($query?"\e[1;96m?".$query:NULL)."\e[0m\n".(!empty($body)&&debugLevel>=2?json_pretty($body)."\n":NULL);
	}
	return $request;
}));
$stack->push(Middleware::mapResponse(function (ResponseInterface $response)
{
	$rbody=$response->getBody();
	$body=trim($rbody->getContents());
	$rbody->rewind();
	$statusCode=$response->getStatusCode();
	if(debugLevel)
	{
		echo "\e[".[0,0,32,33,"1;31","1;35"][floor($statusCode/100)]."m".$statusCode."\e[0m".(!empty($body)&&debugLevel>=2?" ".json_pretty($body):NULL)."\n";
	}
	return $response;
}));

if(!isset($argv[2]))
{
	echo "Specify game ID and API token\n";
	exit;
}
$gameId=$argv[1];
$config=OpenAPI\Client\Configuration::getDefaultConfiguration();
$config->setAccessToken($argv[2]);
if(defined("host"))
{
	$config->setHost(host);
}
$client=new GuzzleHttp\Client(['handler'=>$stack]);

$userApi=new OpenAPI\Client\Api\UserApi($client,$config);
$gameApi=new OpenAPI\Client\Api\GameApi($client,$config);

try {
    $result=$userApi->getSelf();
    $userId=$result->getUserId();
    $username=$result->getUsername();
} catch (Exception $e) {
    echo "\e[31mException when calling UserApi->getSelf: \e[1m", $e->getMessage()."\e[0m\n";
    exit;
}
echo "\e[92mLogged in as ".$username."\n";
$role=$gameApi->getGameRole($gameId)->getRole();
echo "\e[36mRole in this game is \e[96m".$role."\e[0m\n";
$canAttack=in_array($role,["ATTACKER","PLAYER"]);
$canDefend=in_array($role,["DEFENDER","PLAYER"]);
if(!$canAttack&&!$canDefend)
{
	echo "\e[1;31mYou can't do anything in this game\e[0m\n";
	exit;
}
$state=$gameApi->getStatus($gameId)->getState();
echo "\e[36mGame has state \e[96m".$state."\e[0m\n";
if(in_array($state,["CREATED","FINISHED"]))
{
	echo "\e[1;31mThe game is not active\e[0m\n";
	exit;
}
$functions=[
	"Game info"=>[
		'code'=>"i",
		'handler'=>function()
		{
			extract($GLOBALS);
			$status=$gameApi->getStatus($gameId);
			echo "\e[96mGame state\e[0m: ".$status->getState()."\n";
			echo "\e[96mCapturing intentions\e[0m: ".var_export($status->getCapturePlayersIntention(),true)."\n";
			echo "\e[96mMutants\e[0m:\n".implode(array_map(fn($f)=>json_pretty(json_encode(json_decode($f)))."\n",(array)$status->getMutants()));
			echo "\e[96mTests\e[0m:\n".implode(array_map(fn($f)=>json_pretty(json_encode(json_decode($f)))."\n",(array)$status->getTests()));
			$scoreboard=json_decode((string)$status->getScoreboard(),true);
			echo "\e[96mScores\e[0m:\n".implode(array_merge([],...array_map(fn($type,$players)=>array_map(fn($p)=>"\e[36m".$p['username']."\e[0m (".$type."): \e[93m".$p['points']."\e[0m\n",isset($players['username'])?[$players]:$players),array_keys($scoreboard),$scoreboard)));
		},
	],
	"Print class"=>[
		'code'=>"c",
		'handler'=>function()
		{
			extract($GLOBALS);
			$status=$gameApi->getStatus($gameId);
			$classId=$status->getClassId();
			$class=$gameApi->getClass($classId);
			echo $class->getSource()."\n";
		}
	],
	"Save test template"=>[
		'code'=>"tt",
		'handler'=>function()
		{
			extract($GLOBALS);
			$template=$gameApi->getTestTemplate($gameId);
			file_put_contents("test.java",$template->getTemplate());
			echo "Template saved to test.java\n";
		}
	],
	"Save mutant template"=>[
		'code'=>"mt",
		'handler'=>function()
		{
			extract($GLOBALS);
			$status=$gameApi->getStatus($gameId);
			$classId=$status->getClassId();
			$class=$gameApi->getClass($classId);
			file_put_contents("mutant.java",$class->getSource());
			echo "Template saved to mutant.java\n";
		}
	],
	"Upload mutant"=>[
		'code'=>"m",
		'handler'=>function()
		{
			extract($GLOBALS);
			do
			{
				echo "Write your mutant in mutant.java, then press ENTER to send or c to cancel\n";
				$read=readline();
				if($read=="c")
				{
					return;
				}
			} while(!file_exists("mutant.java"));
			$upload_mutant_request=(new \OpenAPI\Client\Model\UploadMutantRequest())->setGameId($gameId)->setSource(file_get_contents("mutant.java"));
			try {
				$result=$gameApi->uploadMutant($upload_mutant_request);
				echo "\e[32mMutant uploaded with ID ".$result->getId()."\n";
			} catch (Exception $e) {
				echo "\e[31mException when calling GameApi->uploadMutant: \e[1m", json_decode($e->getResponseBody())->error."\e[0m\n";
			}
		}
	],
	"List pending claims"=>[
		'code'=>"p",
		'handler'=>function()
		{
			extract($GLOBALS);
			$pending=$gameApi->getPendingEquivalences($gameId)->getMutantIds();
			if(empty($pending))
			{
				echo "No pending equivalence claims\n";
			}
			else
			{
				echo implode(", ",$pending)."\n";
			}
		}
	],
	"Claim lines as equivalent"=>[
		'code'=>"e",
		'handler'=>function()
		{
			extract($GLOBALS);
			$possibleLines=array_merge([],...array_map(fn($m)=>$m->getMutatedLines(),array_filter($gameApi->getStatus($gameId)->getMutants(),fn($m)=>$m->getCanMarkEquivalent())));
			do
			{
				echo "Insert the lines to claim equivalent, separated by a comma: ".implode(", ",$possibleLines)."\n";
				$read=readline();
				$lines=array_map('trim',explode(",",$read));
			} while(empty($lines)||$lines!=array_intersect($lines,$possibleLines));
			$claim_equivalent_request=(new \OpenAPI\Client\Model\ClaimEquivalentRequest())->setGameId($gameId)->setLines($lines);
			try {
				$result=$gameApi->claimEquivalent($claim_equivalent_request);
				echo "\e[32mOK\n";
			} catch (Exception $e) {
				echo "\e[31mException when calling GameApi->uploadMutant: \e[1m", json_decode($e->getResponseBody())->error."\e[0m\n";
			}
		}
	],
	"Accept equivalence"=>[
		'code'=>"ae",
		'handler'=>function()
		{
			extract($GLOBALS);
			$possibleIds=$gameApi->getPendingEquivalences($gameId)->getMutantIds();
			sort($possibleIds);
			if(empty($possibleIds))
			{
				echo "\e[33mNo mutants are claimed\e[0m\n";
				return;
			}
			do
			{
				echo "Choose a mutant ID: ".implode(", ",$possibleIds)."\n";
				$read=readline();
			} while(!in_array($read,$possibleIds));
			$resolve_equivalence_request=(new \OpenAPI\Client\Model\ResolveEquivalenceRequest())->setAccept(true)->setMutantId($read);
			try {
				$result=$gameApi->resolveEquivalence($resolve_equivalence_request);
				echo "\e[32mOK\n";
			} catch (Exception $e) {
				echo "\e[31mException when calling GameApi->uploadMutant: \e[1m", json_decode($e->getResponseBody())->error."\e[0m\n";
			}
		}
	],
	"Counter equivalence"=>[
		'code'=>"ce",
		'handler'=>function()
		{
			extract($GLOBALS);
			$possibleIds=$gameApi->getPendingEquivalences($gameId)->getMutantIds();
			sort($possibleIds);
			if(empty($possibleIds))
			{
				echo "\e[33mNo mutants are claimed\e[0m\n";
				return;
			}
			do
			{
				echo "Choose a mutant ID: ".implode(", ",$possibleIds)."\n";
				$read=readline();
			} while(!in_array($read,$possibleIds));
			$mutantId=$read;
			do
			{
				echo "Write your test in test.java, then press ENTER to send or c to cancel\n";
				$read=readline();
				if($read=="c")
				{
					return;
				}
			} while(!file_exists("test.java"));
			$resolve_equivalence_request=(new \OpenAPI\Client\Model\ResolveEquivalenceRequest())->setAccept(false)->setMutantId($mutantId)->setSource(file_get_contents("test.java"));
			try {
				$result=$gameApi->resolveEquivalence($resolve_equivalence_request);
				echo "\e[32mKilled claimed: ".var_export($result->getKilledClaimed(),true).", and ".$result->getKilledOthers()." others\n";
			} catch (Exception $e) {
				echo "\e[31mException when calling GameApi->uploadMutant: \e[1m", json_decode($e->getResponseBody())->error."\e[0m\n";
			}
		}
	],
	"Upload test"=>[
		'code'=>"t",
		'handler'=>function()
		{
			extract($GLOBALS);
			do
			{
				echo "Write your test in test.java, then press ENTER to send or c to cancel\n";
				$read=readline();
				if($read=="c")
				{
					return;
				}
			} while(!file_exists("test.java"));
			$upload_test_request=(new \OpenAPI\Client\Model\UploadTestRequest())->setGameId($gameId)->setSource(file_get_contents("test.java"));
			try {
				$result=$gameApi->uploadTest($upload_test_request);
				echo "\e[32mTest uploaded with ID ".$result->getId()."\n";
			} catch (Exception $e) {
				echo "\e[31mException when calling GameApi->uploadMutant: \e[1m", json_decode($e->getResponseBody())->error."\e[0m\n";
			}
		}
	],
	"Quit"=>[
		'code'=>"q",
		'handler'=>function()
		{
			exit;
		},
	],
];
while(true)
{
	echo "\n".implode("\n",array_map(fn($k,$f)=>"\e[93m".$f['code']."\e[0m:\t".$k,array_keys($functions),$functions))."\n\n";
	$read=readline();
	$f=array_filter($functions,fn($f)=>$f['code']==$read);
	if(current($f))
	{
		current($f)['handler']();
	}
}
function json_pretty($json)
{
	file_put_contents("tmp.json",$json);
	$out=trim(shell_exec("jq -cC < tmp.json"));
	unlink("tmp.json");
	return $out;
}
?>
